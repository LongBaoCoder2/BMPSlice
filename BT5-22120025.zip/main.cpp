#include "Interface.h"

int main(int argc, char **argv) {
	BMPSliceApplication(argc, argv);

	return 0;
}
